<?php
/*
 *  * Plugin Name: Darkroom
 *  * Plugin URI: http://www.innerturtle.com/darkroom
 *  * Description: Implements a full-fledged photo gallery function within WordPress.
 *  * Version: 1.0
 *  * Author: Jed (jed@innerturtle.com)
 *  * Author URI: http://www.innerturtle.com
 *
 *  * Please use darkroom@innerturtle.com to contact me about this plugin! Thanks.
 *  
 *  (c) Copyright 2008 innerturtle.com  (email : darkroom@innerturtle.com)
 * 
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 * 
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 * 
 *     You should have received a copy of the GNU General Public License
 *     along with this program; if not, write to the Free Software
 *     Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * */


// ********** BEGIN setup section.
// This section runs all the scripts that setup the plugin. This includes adding Javascript for lightbox,
// adding the options pages to the admin menu, and making sure the options have a value (or a default
// value.

// Pre-2.6 compatibility
if ( ! defined( 'WP_CONTENT_URL' ) )
      define( 'WP_CONTENT_URL', get_option( 'siteurl' ) . '/wp-content' );
if ( ! defined( 'WP_CONTENT_DIR' ) )
      define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' );
if ( ! defined( 'WP_PLUGIN_URL' ) )
      define( 'WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins' );
if ( ! defined( 'WP_PLUGIN_DIR' ) )
      define( 'WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins' );

// This adds the necessary scripts for lightbox to work...
wp_enqueue_script('mootools', WP_PLUGIN_URL . '/darkroom/slimbox-1.65/js/mootools.js');
wp_enqueue_script('slimbox', WP_PLUGIN_URL . '/darkroom/slimbox-1.65/js/slimbox.js');

// This adds the stylesheet necessary for lightbox.
add_action('wp_head','jpg_slimbox_stylesheet');

// This checks the options to make sure they are set and puts-in a default value if necessary.
jpg_validate_options();

// Hook for adding admin menus
add_action('admin_menu', 'jpg_add_option_page');

// Hook for actually dsplaying the gallery page
add_filter('the_content','jpg_insert_gallery_content');

// Hook to initialize the widget
add_action("plugins_loaded", "darkroom_widget_init");

global $jpg_did_setup; $jpg_did_setup = FALSE;

// ********** END setup section

// ********** BEGIN the content of the gallery page
function jpg_insert_gallery_content($the_content) { #this is called by calling the add_filter hook with the_content
	if (is_darkroom()) {
		jpg_content();
    } else { 
		return $the_content; 
	}
}

function jpg_content() {
	global $jpg_collections; 
	global $form_collection;
	$jpg_picsdirectory = get_option('jpg_picsdirectory');
    $jpg_usesidebar = get_option('jpg_usesidebar');
    $jpg_gallery_h2 = get_option('jpg_gallery_h2');
	$jpg_colname = get_option('jpg_colname');
    if ($jpg_usesidebar == 'y') { $jpg_usesidebar = TRUE; } else { $jpg_usesidebar = FALSE; }
    $jpg_daysnew = get_option('jpg_daysnew');

	jpg_setup_variables();
    
    if ($form_collection) {
		$the_collection = $jpg_picsdirectory . $form_collection;
		if (file_exists($the_collection)) {
		    echo '<h2 '.$jpg_gallery_h2.'> ' . $jpg_colname . ': '.$form_collection."\n";
		    if (!$jpg_usesidebar) {
			echo '&nbsp;&nbsp;&nbsp;&nbsp;<a style="font: bold 75% sans-serif; color: gray;" href="'.get_permalink().'">&uarr; back</a>';
		    }
		    echo '</h2>';
		    $collection_files = jpg_collection_files_array($the_collection);
		    $c_directory = $the_collection . '/';
		    foreach ($collection_files AS $c_file => $c_date) {
			$the_description = jpg_get_file_desc($c_directory.$c_file);
			$the_datetime = jpg_get_pic_datetime($c_directory.$c_file);
			echo '<div style="margin-bottom: 10px; margin-top: 10px;"><table width=100% border=0 style="border-collapse: collapse;"><tr valign=top>';
			echo '<td width=160 align=center><a href="' . WP_PLUGIN_URL . '/darkroom/get-image.php?op=image&file='.$form_collection.'/'.$c_file.'" rel="lightbox['.$form_collection.']" title="'.$c_file.': '.$the_description.'">';
		        echo '<img src="' . WP_PLUGIN_URL . '/darkroom/get-image.php?op=thumb&file='.$form_collection.'/'.$c_file.'" border=0></a></td>';
			echo '<td style="border-left: solid #F0F0F0 2px;"><strong>'.$c_file.'</strong><br>'.$the_description.'<br><br><em>'.$the_datetime.'</em>';
			echo '</tr></table></div>'."\n";
		    }	
		} else {
		    echo "<p><font color=red><i>We're sorry, the collection you specified, $form_collection, does not exist...</i></font></p>";
		    $form_collection = NULL;
		}
    }
        
    if (!$form_collection) {
		if (count($jpg_collections) <= 0) {
			echo "<p><font color=red><i>No pictures have been added to the gallery yet.</i></font></p>";
		} else {
			if ($jpg_usesidebar) {
				$number_random = 3;
				if (count($jpg_collections) < $number_random) { $number_random = count($jpg_collections);}
				$rand_colls = array_rand($jpg_collections, $number_random);
				foreach ($rand_colls as $the_coll) {
					$coll_directory = $jpg_picsdirectory . $the_coll . $the_collection . '/';
					$coll_files = jpg_collection_files_array($coll_directory);
					#echo '<pre>'.var_dump($coll_files).'</pre>';
					$rand_pic = array_rand($coll_files);
					$the_description = jpg_get_file_desc($coll_directory.$rand_pic);
					$the_datetime = jpg_get_pic_datetime($coll_directory.$rand_pic);
					echo '<a href="?col=' . $the_coll . '"><h2 '.$jpg_gallery_h2.'>'.$the_coll.'</h2></a>'."\n";
					echo '<div style="margin-bottom: 10px; margin-top: 10px;"><table width=100% border=0 style="border-collapse: collapse;"><tr valign=top>';
					echo '<td width=160 align=center><a href="?col=' . $the_coll . '">';
					echo '<img src="' . WP_PLUGIN_URL . '/darkroom/get-image.php?op=thumb&file='.$the_coll.'/'.$rand_pic.'" border=0></td>';
					echo '<td style="border-left: solid #F0F0F0 2px;"><strong>' . $rand_pic . '</strong><br>'.$the_description.'<br><br><em>'.$the_datetime.'</em></td>';
					echo '</tr></table></div>'."\n";
				}
			} else { //not usesidebar
				foreach ($jpg_collections as $c_entry => $c_date) {
					$the_dateinfo = date("F j, Y", $c_date);
					$the_dateinfo = jpg_add_new_if_new($the_dateinfo, $c_date);
					$coll_directory = $jpg_picsdirectory . $c_entry . $the_collection . '/';
					$coll_files = jpg_collection_files_array($coll_directory);
					asort($coll_files);
					$rand_pic = key($coll_files);
					echo '<div style="margin-bottom: 10px; margin-top: 10px;"><table width=100% border=0 style="border-collapse: collapse;"><tr valign=top>';
					echo '<td width=160 align=center><a href="?col=' . $c_entry . '">';
					echo '<img src="' . WP_PLUGIN_URL . '/darkroom/get-image.php?op=thumb&file='.$c_entry.'/'.$rand_pic.'" border=0></td>';
					echo '<td style="border-left: solid #F0F0F0 2px;"><a href="?col=' . $c_entry . '"><strong>' . $c_entry . '</strong></a><br><em>'.$the_dateinfo.'</em></td>';
					echo '</tr></table></div>'."\n";
				}
			}
		}
	}
}

function darkroom_sidebar($include_timestamps = TRUE, $is_item = TRUE, $title_before = '<h2><em>', $title_after = '</em></h2>', $list_class = 'categories', $is_widget = FALSE) {	
	global $jpg_collections;
	global $form_collection;
	$jpg_sidebarhighlight = get_option('jpg_sidebarhighlight');
	$jpg_usesidebar = get_option('jpg_usesidebar');
	$jpg_aboutinsidebar = get_option('jpg_aboutinsidebar');
	$jpg_abouttext = get_option('jpg_abouttext');
	$jpg_highlightto = get_option('jpg_highlightto');
	$head_name = 'gone';
	$jpg_sidebarname = get_option('jpg_sidebarname');
	
	if ((is_darkroom() AND $jpg_usesidebar == 'y') OR $is_widget) {
		jpg_setup_variables();
		if (!is_null($list_class) AND $list_class <> '') {
			$add_list_class = ' class="' . $list_class . '"';
		} else {
			$add_list_class = '';
		}
		if ($jpg_aboutinsidebar == 'y' AND (is_null($form_collection) OR $form_collection == '')) {
			if ($is_item) { echo "<li>"; }
			echo $title_before . 'About' . $title_after;
			echo '<p>' . $jpg_abouttext . "</p>\n";
			if ($is_item) { echo "</li>"; }
		}
		
		if ($is_item) { echo "<li>"; }
		echo $title_before . $jpg_sidebarname . $title_after;
		echo '<ul' . $add_list_class . ">\n";
		arsort($jpg_collections);
		foreach ($jpg_collections as $c_entry => $c_date) {
			if ($form_collection == $c_entry AND $jpg_sidebarhighlight != FALSE) { 
			$set_bg = ' style="background-color: #' . $jpg_sidebarhighlight . ';"'; 
			} else { 
				$set_bg = '';
			}
			$the_dateinfo = date("F j, Y", $c_date);
			$the_dateinfo = jpg_add_new_if_new($the_dateinfo, $c_date);
			if ($jpg_highlightto == 'li') {
				echo '<li' . $set_bg . '>';
			} else {
				echo '<li>';
			}
			if ($jpg_highlightto == 'a') {
				echo '<a ' . $set_bg . ' href="?col=' . $c_entry . '">' . $c_entry . '</a>';
			} else {
				echo '<a href="?col=' . $c_entry . '">' . $c_entry . '</a>';
			}
			if ($include_timestamps) { echo '<em style="font-size: .8em;">' . $the_dateinfo . '</em>'; }
			echo "</li>\n";
		}
		echo '</ul></li>';
		if ($is_item) { echo "</li>"; }
	}
}

function darkroom_footer($before='', $after='<br />') {
	$jpg_daysnew = get_option('jpg_daysnew');
	if (is_darkroom()) {
		echo $before . 'A <font color="#ffcc00"><b>NEW</b></font> picture or collection has been shot within the past <b>' . $jpg_daysnew . '</b> days.' . $after;
	}
}

function is_darkroom() {
	global $post;
	if (!is_null($post)) {
		$this_ID = $post->ID;
		$jpg_custom_value = get_post_meta($this_ID, 'darkroom', TRUE);
		if (get_post_type() == 'page' AND $jpg_custom_value == 'true') {
			return TRUE;
		} else { 
			return FALSE; 
		}
	} else {
		return FALSE;
	}
}

function darkroom_widget($args) {
	if (is_darkroom()) {
		extract($args);
		echo $before_widget;
		darkroom_sidebar(FALSE,FALSE,$before_title,$after_title,'categories',TRUE);
		echo $after_widget;
	}
}

function darkroom_widget_init() {
	register_sidebar_widget(__('Darkroom'), 'darkroom_widget');
}

// ********** END the content of the gallery page

// ********* BEGIN the options menu 
// displays the page content for the options submenu on the admin pages
function jpg_options_page() { #this function actually displays the options page
    global $wpdb;
?>
	<div class="wrap">
      	<h2>Darkroom Options</h2>
      	<form method="post" action="options.php">
      	<?php wp_nonce_field('update-options'); ?>
      	<h3 style="margin-top: 10px; margin-bottom: 0px;">General Settings</h3><table class="form-table">      	
	<tr valign="top"><th scope="row">Gallery Page</th>
		<td><?php
                      $sql = "SELECT ID, post_title FROM $wpdb->posts, $wpdb->postmeta WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id AND $wpdb->posts.post_type = 'page' AND ($wpdb->postmeta.meta_key='darkroom' AND $wpdb->postmeta.meta_value='true');";
                      $result = $wpdb->get_results($sql, ARRAY_A);
                      if(count($result)==0) {
			  echo "<font color=red><b>Note: </b></font>Your gallery will not show-up because you haven't setup a page for it. Create a new page with a <i>custom field</i>. The KEY should be <font face=monospace>darkroom</font> and the VALUE should be <font face=monospace>true</font>. Your gallery will not work until this is done.";
		      } else {
			  if (count($result)>1) { $echo_pages = "pages"; } else { $echo_pages = "page"; }
			  echo "Your photo gallery will appear in, and completely replace the contents of, the following $echo_pages: ";
			  foreach ( $result as $jpg_page ) {
					## *************************** HELP
			      echo '<a href="page.php?action=edit&post=' . $jpg_page['ID'] . '">' . $jpg_page["post_title"] . '</a>&nbsp;&nbsp;&nbsp;';
			  }
			  if ($echo_pages == 'pages') { 
			      echo "<p style=\"margin-bottom: 0;\"><font color=red><b>Note: </b></font>If you wish to limit the gallery to only one page, delete the extra page(s) or remove the <i>custom field</i> with the KEY of <font face=monospace>darkroom</font> from the extra page(s).</p>";
			  }
		      }
                ?></td></tr>
	<tr valign="top"><th scope="row">Pic Directory</th>
		<td><input name="jpg_picsdirectory" type="text" value="<?php echo get_option('jpg_picsdirectory'); ?>" /><br />
		The location of the pictures. This must be relative to <?php bloginfo('url'); ?>/ and also <?php echo $_SERVER['DOCUMENT_ROOT']; ?>/.</td></tr>
      	<!--<tr valign="top"><th scope="row">Image Processor</th>
		<td><select name="jpg_processor" id="jpg_processor">
	  	<option value="gd" <?php if(get_option('jpg_processor')=="gd") { echo "selected"; } ?>>gd</option>
	  	<option value="im" <?php if(get_option('jpg_processor')=="im") { echo "selected"; } ?>>ImageMagick</option>
	  	</select> ImageMagick may not work on your web hosting platform...</td></tr>-->
     <tr valign="top"><th scope="row">Label for Collections</th>
	  	<td><input name="jpg_colname" type="text" value="<?php echo get_option('jpg_colname'); ?>" size="20" />
	  	this is used when the collection is displayed</td></tr>
	<tr valign="top"><th scope="row">How Long are Pictures New?</th>
	  	<td><input name="jpg_daysnew" type="text" value="<?php echo get_option('jpg_daysnew'); ?>" size="2" maxlength="2"/>
	  	must be between 1 and 99 days</td></tr>
	<tr valign="top"><th scope="row">Picture Copyright Watermark</th>
	        <td>&copy;&nbsp;<input name="jpg_copyright" type="text" size="30" maxlength="30" value="<?php echo get_option('jpg_copyright'); ?>" />
	        limit 30 characters, do not include &copy;, it will be prepended automatically.</td></tr>
	</table><h3 style="margin-top: 10px; margin-bottom: 0px;">Sidebar Settings</h3><table class="form-table">
	<tr valign="top"><th scope="row">Use Sidebar for Navigation</th>
		<td>
	        <label><input type="radio" name="jpg_usesidebar" value="y" <?php if (get_option('jpg_usesidebar')=="y") { echo "checked=\"checked\""; }?> /> Yes</label><br />
                <label><input type="radio" name="jpg_usesidebar" value="n" <?php if (get_option('jpg_usesidebar')=="n") { echo "checked=\"checked\""; }?> /> No</label><br />
		</td></tr>
     <tr valign="top"><th scope="row">Sidebar Heading</th>
	  	<td><input name="jpg_sidebarname" type="text" value="<?php echo get_option('jpg_sidebarname'); ?>" size="20" />
	  	this is the heading for the sidebar.</td></tr>
	<tr valign="top"><th scope="row">Display About in Sidebar</th>
		<td>
	        <label><input type="radio" name="jpg_aboutinsidebar" value="y" <?php if (get_option('jpg_aboutinsidebar')=="y") { echo "checked=\"checked\""; }?> /> Yes</label><br />
                <label><input type="radio" name="jpg_aboutinsidebar" value="n" <?php if (get_option('jpg_aboutinsidebar')=="n") { echo "checked=\"checked\""; }?> /> No</label><br />
		</td></tr>
	<tr valign="top"><th scope="row">About Text for Sidebar</th>
	        <td><textarea name="jpg_abouttext" cols="60" rows="3" style="width: 98%; font-size: 12px;" class="code"><?php echo get_option('jpg_abouttext'); ?></textarea></td></tr>
	<tr valign="top"><th scope="row">Sidebar Highlight Color</th>
	  	<td>#<input name="jpg_sidebarhighlight" type="text" value="<?php echo get_option('jpg_sidebarhighlight'); ?>" size="6" maxlength="6"/>
	  	hex color value for higlight color. leave blank for no highlight</td></tr>
	<tr valign="top"><th scope="row">Sidebar Highlight Applies To</th>
		<td><select name="jpg_highlightto" id="jpg_highlightto">
	  	<option value="li" <?php if(get_option('jpg_highlightto')=="li") { echo "selected"; } ?>>list item</option>
		<option value="a" <?php if(get_option('jpg_highlightto')=="a") { echo "selected"; } ?>>anchor</option>
		</select> This sets which part of your sidebar gets the highlight. If one setting doesn't work, try the other.</td></tr>
	</table>
	<h3 style="margin-top: 10px; margin-bottom: 0px;"><span style="color: red;">ADVANCED USERS ONLY</span> below this line. Please!</h3><table class="form-table">
	<tr valign="top"><th scope="row">Gallery Heading Customization</th>
	        <td>&lt;h2&nbsp;<input name="jpg_gallery_h2" type="text" size="50" maxlength="50" value="<?php echo htmlspecialchars(get_option('jpg_gallery_h2')); ?>" />&gt;<br />
	        the words <u>java</u> and <u>script</u> will be automatically removed from anything you put here</td></tr>
    <?php
		$the_table=get_option('jpg_dbtable');
		$result = $wpdb->get_results("SHOW TABLES like '$the_table'");
		if (count($result) > 0) {
			$table_folders = $wpdb->get_var("SELECT count(folder) FROM $the_table;");
			if ($table_folders === NULL) {
				$jpg_dbtableexists = FALSE;
				$jpg_dbtablealreadyinuse = TRUE;
			} else {
				$jpg_dbtableexists = TRUE;
			}
		} else {
			$jpg_dbtableexists = FALSE;
		}
		
		if ($jpg_dbtableexists == FALSE) {
			if (get_option('jpg_usedb') == 'y') {
				$jpg_dbturnedoff = TRUE;
				update_option('jpg_usedb','n');
			} else {
				$jpg_dbturnedoff = FALSE;
			}
		}
	?>
	<tr valign="top"><th scope="row">Use Database Cache</th>
		<td>
	        <label><input type="radio" name="jpg_usedb" value="y" <?php if (get_option('jpg_usedb')=="y") { echo "checked=\"checked\""; }?> /> Yes</label><br />
            <label><input type="radio" name="jpg_usedb" value="n" <?php if (get_option('jpg_usedb')=="n") { echo "checked=\"checked\""; }?> /> No</label><br />
			If this option is selected, the plugin will use the database to keep cached information about your collections, speeding up the plugin.
			<?php if ($jpg_dbturnedoff) { ?>
				<font color=red><b>NOTE: </b></font>This option has been automatically turned off because the database table specified below doesnt exist.
			<?php } ?>
			<?php if (!$jpg_dbtableexists) { ?>
				<b>NOTE: </b>You must create the table using the option below in order to turn on this option.
			<?php } ?>
		</td></tr>
	<tr valign="top"><th scope="row">Database Table</th>
		<td><input name="jpg_dbtable" type="text" value="<?php echo get_option('jpg_dbtable'); ?>" /><br />
		<?php if ($jpg_dbtableexists) { ?>
			The table <font face=monospace><?php echo $the_table ?></font> already exists. There are currently <?php echo $table_folders; ?> collections stored in the table.
		<?php } else { ?>
			<?php if ($jpg_dbtablealreadyinuse) { ?>
					<font color=red><b>WARNING: </b></font>This table exists but does not appear to have valid data in it. <b>It may be in use by another program or plugin.</b> You
					can either change the database table name above or overwrite the existing data by recreating the table with the option below.
			<?php } else { ?>
				This table doesn't exist. If you'd like to create it, use the option below.
			<?php } ?>
		<?php } ?>
		</td></tr>
	<tr valign="top"><th scope="row">Create/Recreate Database Table</th>
		<td>
	        <label><input type="radio" name="jpg_createtable" value="y" <?php if (get_option('jpg_createtable')=="y") { echo "checked=\"checked\""; }?> /> Yes</label><br />
                <label><input type="radio" name="jpg_createtable" value="n" <?php if (get_option('jpg_createtable')=="n") { echo "checked=\"checked\""; }?> /> No</label><br />
		<?php if (count($result) >= 1) { ?>
		<b>Proceed at your own risk: </b></font>This will <font color=red>delete <b>ALL</b> data </font> in the table <font face=monospace><?php echo $the_table; ?></font>, even if it is not related to this plugin!
		<?php } ?>
		<?php if ($jpg_dbtablealreadyinuse) { ?>
			<font color=red><b>WARNING: </b></font>This table does not appear to have valid data in it. <b>It may be in use by another program or plugin.</b>
		<?php }?>
		</td></tr>
		<tr valign="top"><th scope="row">Database Refresh Interval</th>
		<td><select name="jpg_dbrefresh" id="jpg_dbrefresh">
	  	<option value="-6 hours" <?php if(get_option('jpg_dbrefresh')=="-6 hours") { echo "selected"; } ?>>6 hours</option>
		<option value="-12 hours" <?php if(get_option('jpg_dbrefresh')=="-12 hours") { echo "selected"; } ?>>12 hours</option>
		<option value="-1 day" <?php if(get_option('jpg_dbrefresh')=="-1 day") { echo "selected"; } ?>>1 day</option>
	  	</select> This dictates how frequently the collections will be cached in the database to speed up the plugin.</td></tr>
	<tr valign="top"><th scope="row">DB Refresh Now</th>
		<td>
	        <label><input type="radio" name="jpg_dodbrefresh" value="y" <?php if (get_option('jpg_dodbrefresh')=="y") { echo "checked=\"checked\""; }?> /> Yes</label><br />
            <label><input type="radio" name="jpg_dodbrefresh" value="n" <?php if (get_option('jpg_dodbrefresh')=="n") { echo "checked=\"checked\""; }?> /> No</label><br />
			This will set the database so the next time your gallery is loaded, the collections cache will be refreshed.</td></tr>
	</table>
	
		
	
      	<input type="hidden" name="action" value="update" />
      	<input type="hidden" name="page_options" value="jpg_picsdirectory,jpg_processor,jpg_daysnew,jpg_aboutinsidebar,jpg_abouttext,jpg_copyright,jpg_usesidebar,jpg_gallery_h2,jpg_dbtable,jpg_createtable,jpg_dbrefresh,jpg_dodbrefresh,jpg_usedb,jpg_sidebarhighlight,jpg_highlightto,jpg_colname,jpg_sidebarname" />
	<div class="submit"><input type="submit" name="Submit" value="<?php _e('Save Changes') ?>" /></div>
      	</form>
      	<!--<pre><?php phpinfo(); ?> </pre>-->
    	</div>
<?php      
}
// **********END the options menu

// ********** BEGIN all JPG functions
// ********** These are functions that are used/called from other places.

function jpg_slimbox_stylesheet() {
    echo '<link rel="stylesheet" href="' . WP_PLUGIN_URL . '/darkroom/slimbox-1.65/css/slimbox.css" type="text/css" media="screen" />';
}

//*****************************************************************************************
//*****************************************************************************************
//*****************************************************************************************
function jpg_setup_variables() {
	global $jpg_did_setup;
	if (!$jpg_did_setup) {
		global $jpg_collections; 
		global $form_collection;
		$jpg_usesidebar = get_option('jpg_usesidebar');
		$jpg_dbtable = get_option('jpg_dbtable');
		$jpg_dbrefresh = get_option('jpg_dbrefresh');
		$jpg_usedb = get_option('jpg_usedb');
		$jpg_dblastupdate = get_option('jpg_dblastupdate');
		$jpg_picsdirectory = get_option('jpg_picsdirectory');
		
		if (array_key_exists('col',$_GET)) { $form_collection = $_GET['col']; } else { $form_collection = NULL; }
		if ($form_collection == "" ) { $form_collection = NULL; }
		
		if (!$form_collection OR $jpg_usesidebar) {
			global $wpdb;
			if ($jpg_usedb == 'y' AND (int)$jpg_dblastupdate < strtotime($jpg_dbrefresh)) {
			    update_option('jpg_dblastupdate',time());
			    $sql = "TRUNCATE TABLE $jpg_dbtable;";
			    $wpdb->query($sql);
			    $proc_directory = opendir($jpg_picsdirectory);
			    while (false !== ($filename = readdir($proc_directory))) {
				if ( $filename!== "." and $filename !== ".." and is_dir($jpg_picsdirectory.$filename) and jpg_collection_has_image($jpg_picsdirectory.$the_filename)) {
				    $filetime = jpg_get_dir_ts($filename);
				    $sql = "INSERT INTO $jpg_dbtable VALUES ('$filename', '$filetime')";
				    $wpdb->query($sql);
				}
			    }
			}
			$the_directory = opendir($jpg_picsdirectory);
			while (false !== ($the_filename = readdir($the_directory))) {
			     if ( $the_filename!= "." and $the_filename != ".." and is_dir($jpg_picsdirectory.$the_filename) and jpg_collection_has_image($jpg_picsdirectory.$the_filename)) {
					if ($jpg_usedb == 'y') {
						$sql = "SELECT * FROM $jpg_dbtable WHERE folder='$the_filename'";
						$row = $wpdb->get_results($sql, ARRAY_A);
						$row = $row[0];
					} else {
						$row = FALSE;
					}
					if ( $row ) {
					    $jpg_collections[$the_filename] = $row['datetime'];
					} else {
					    $filetime = jpg_get_dir_ts($the_filename);
					    $jpg_collections[$the_filename] = $filetime;
					    if ($jpg_usedb == 'y') { 
							$sql="INSERT INTO $jpg_dbtable VALUES ('$the_filename', '$filetime')";
							$wpdb->query($sql);
						}
					}
			     }
			}
			if (count($jpg_collections) > 0) { arsort($jpg_collections);}
	    }
		$jpg_did_setup = TRUE;
	}
}

function jpg_validate_options() { #called in the setup section to check the options and add a default value if necesary
    // Note: This also checks *some* values to see if they are out-of-range and resets them to the default.
    // Note: This also does some data validation for entries made on the admin options page.
    if (get_option('jpg_daysnew')==FALSE) {update_option('jpg_daysnew','14');}
    if (get_option('jpg_sidebarname')==FALSE) {update_option('jpg_sidebarname','Collections');}
    if (get_option('jpg_imageprocessor')==FALSE) {update_option('jpg_imageprocessor','gd');}
    if (get_option('jpg_picsdirectory')==FALSE) {update_option('jpg_picsdirectory','pics/');}
    if (get_option('jpg_picsdirectory')=='') {update_option('jpg_picsdirectory','pics/');}
    if (get_option('jpg_abouttext')==FALSE) {update_option('jpg_abouttext','Welcome! You will notice on the main Pictures page there are three random pictures. Click a picture or its heading to start exploring or choose one of the collection names below.');}
    if (get_option('jpg_aboutinsidebar')==FALSE) {update_option('jpg_aboutinsidebar','n');}
    if (get_option('jpg_usesidebar')==FALSE) {update_option('jpg_usesidebar','n');}
	if (get_option('jpg_dbrefresh')==FALSE) {update_option('jpg_dbrefresh','-1 day');}
	if (get_option('jpg_dodbrefresh')==FALSE) {update_option('jpg_dodbrefresh','n');}
	if (get_option('jpg_highlightto')==FALSE) {update_option('jpg_highlightto','li');}
	if (get_option('jpg_usedb')==FALSE) {update_option('jpg_usedb','n');}
	if (get_option('jpg_colname')==FALSE) {update_option('jpg_colname','Collection');}
    $the_picsdirectory = get_option('jpg_picsdirectory');
    if (substr($the_picsdirectory,0,1)=="/") { $the_picsdirectory = substr($the_picsdirectory,1) ;}
    if (substr($the_picsdirectory,strlen($the_picsdirectory)-1,1)<>"/") { $the_picsdirectory = $the_picsdirectory . "/";}
    if (substr($the_picsdirectory,strlen($the_picsdirectory)-2,2)=="//") { $the_picsdirectory = substr($the_picsdirectory,0,strlen($the_picsdirectory)-1) ;}
    update_option('jpg_picsdirectory',$the_picsdirectory);
    $the_daysnew = get_option('jpg_daysnew');
      if ( (int)$the_daysnew < 1 ) { $the_daysnew = '14'; }
      if ( (int)$the_daysnew > 99 ) { $the_daysnew = '14'; }
    update_option('jpg_daysnew',$the_daysnew);
    if (get_option('jpg_copyright')==FALSE) {update_option('jpg_copyright',get_bloginfo(''));}
    if (get_option('jpg_copyright')=='') {update_option('jpg_copyright',get_bloginfo(''));}
    $the_copyright = get_option('jpg_copyright');
    if (substr($the_copyright,0,1) == "�") {update_option('jpg_copyright',substr($the_copyright,1));}
    update_option('jpg_copyright',trim($the_copyright));
    if (get_option('jpg_gallery_h2')==FALSE) {update_option('jpg_gallery_h2','');}
    $the_gallery_h2 = get_option('jpg_gallery_h2');
      $the_gallery_h2 = str_ireplace('<','',$the_gallery_h2);
      $the_gallery_h2 = str_ireplace('>','',$the_gallery_h2);
      $the_gallery_h2 = str_ireplace('&gt;','',$the_gallery_h2);
      $the_gallery_h2 = str_ireplace('&lt;','',$the_gallery_h2);
      $the_gallery_h2 = str_ireplace('java','',$the_gallery_h2);
      $the_gallery_h2 = str_ireplace('script','',$the_gallery_h2);
    update_option('jpg_gallery_h2',$the_gallery_h2);
    if (get_option('jpg_dbtable')==FALSE) {update_option('jpg_dbtable','darkroom_collections'); }
    if (get_option('jpg_dbtable')=='') {update_option('jpg_dbtable','darkroom_collections');}
    if (get_option('jpg_dblastupdate')==FALSE) {update_option('jpg_dblastupdate','0');}
    if (get_option('jpg_createtable')==FALSE) {update_option('jpg_createtable','n');}
    $the_table = get_option('jpg_dbtable');
      $the_table = str_replace(' ','',$the_table);
      $the_table = str_ireplace('.','',$the_table);
      $the_table = str_ireplace(';','',$the_table);
      $the_table = str_ireplace('(','',$the_table);
      $the_table = str_ireplace(')','',$the_table);
      $the_table = str_ireplace('end','',$the_table);
      $the_table = str_ireplace('commit','',$the_table);
      $the_table = str_ireplace('break','',$the_table);
    update_option('jpg_dbtable',$the_table);
    if (get_option('jpg_createtable')=='y') {
	$the_db = DB_NAME; global $wpdb; 
	$sql = "DROP TABLE IF EXISTS $the_db.$the_table;";
	$wpdb->query($sql);
	$sql = " CREATE TABLE $the_db.$the_table ( folder varchar(255) NOT NULL default '',datetime varchar(128)  NOT NULL default '',PRIMARY KEY  (folder));";
	$wpdb->query($sql);
	update_option('jpg_createtable','n');
    }
	if (get_option('jpg_dodbrefresh')=='y') {
		update_option('jpg_dblastupdate','0');
		update_option('jpg_dodbrefresh','n');
	}
	if (get_option('jpg_usedb')=='n') {
		update_option('jpg_dblastupdate','0');
	}
	if (!in_array(get_option('jpg_dbrefresh'), array("-6 hours","-12 hours","-1 day"))) {
		update_option('jpg_dbrefresh','-1 day');
	}
}

function jpg_add_option_page() { #this is called in the setup section with add_action via admin_menu
    // Add a new submenu under Options:
    add_options_page('Darkroom Options', "Darkroom", 8, 'darkroom_options', 'jpg_options_page');   
}

function jpg_get_file_desc($the_file) { #was GetDescription
    $the_usercomment = "";
	$old_error_level = error_reporting(1);
    $exif = exif_read_data($the_file, 'EXIF', true, false);
	$old_error_level = error_reporting($old_error_level);
    $read_comment = rtrim($exif['COMMENT'][0]);
    if (strlen($read_comment) < 1) {
	$the_usercomment = "<i>no description available</i>";
    } else {
	$the_usercomment = $read_comment;
    }
		
    if ($the_usercomment == "<i>no description available</i>") {
	$read_comment = rtrim($exif['IFD0']['ImageDescription']);
        if (strlen($read_comment) < 1) {
	    $the_usercomment = "<i>no description available</i>";
    	} else {
	    $the_usercomment = $read_comment;
    	}
    }

    if ($the_usercomment == "<i>no description available</i>") {
	$read_comment = rtrim($exif['WINXP']['Title']);
	if (strlen($read_comment) < 1) {
	                $the_usercomment = "<i>no description available</i>";
	} else {
	                $the_usercomment = $read_comment;
	}
    }
    
		if ($the_usercomment == "<i>no description available</i>") {
			 $read_comment = rtrim($exif['EXIF']['UserComment']);
			 if (strlen($read_comment) > 8) { 
	     		$the_usercomment = substr($read_comment, 8);
    	 } else {
	     	 $the_usercomment = "<i>no description available</i>";
    	 }
		}
		
		if ($the_usercomment == "<i>no description available</i>") {
			 $size = getimagesize($the_file, $info);
			 if (isset($info["APP13"])) {
			 		$iptc = iptcparse($info["APP13"]);
					if (isset($iptc["2#120"][0])) { 
					 		$the_usercomment =  $iptc["2#120"][0];
					} else {
							$the_usercomment = "<i>no description available</i>";
					}
    		} else {
						$the_usercomment = "<i>no description available</i>";
    		}
		 }
		
    return $the_usercomment;
}
    
function jpg_get_file_ts($the_file) { #was getexiftimestamp
    $old_error_level = error_reporting(1);
    $exif = exif_read_data($the_file, 'EXIF', true, false);
    $old_error_level = error_reporting($old_error_level);
      
    if ($exif != FALSE) {
	if (isset($exif['EXIF']['DateTimeOriginal'])) {
	    $read_datetime = rtrim($exif['EXIF']['DateTimeOriginal']);
	} elseif (isset($exif['EXIF']['DateTime'])) {
	    $read_datetime = rtrim($exif['EXIF']['DateTime']);
	} else {
	    $exif = FALSE;
	}
	if ($read_datetime <= 0) { $exif = FALSE; }
    }
    
    if ($exif != FALSE) {
	$the_year = substr($read_datetime, 0, 4);
	$the_month = substr($read_datetime, 5, 2);
	$the_day = substr($read_datetime, 8, 2);
	$the_hour = substr($read_datetime, 11, 2);
	$the_minute = substr($read_datetime, 14, 2);
	$the_second = substr($read_datetime, 17, 2);
	if (strlen($the_hour) < 1) { $the_hour = -1; }
	if (strlen($the_minute) < 1) { $the_minute = -1; }
	if (strlen($the_second) < 1) { $the_second = -1; }
	if ( ($the_year > 0) and ($the_month > 0) and ($the_day > 0) and ($the_hour >= 0) and ($the_minute >= 0) and ($the_second >= 0) ) {
	    $the_datetime = mktime( $the_hour, $the_minute, $the_second, $the_month, $the_day, $the_year);
	} else {
	    $exif = FALSE;
	}
    }
    
    if ($exif == FALSE OR $the_datetime <=0){
	$the_datetime = filemtime($the_file);
    }
    return $the_datetime;
}

function jpg_get_pic_datetime($the_file) { #was getdatetime
    $the_timestamp = jpg_get_file_ts($the_file);
    if ($the_timestamp > 0) {
	$the_datetime = date("F j, Y G:i:s", $the_timestamp);
	$the_datetime = jpg_add_new_if_new($the_datetime, $the_timestamp);
    } else {
	$the_datetime = "no timestamp available";
    }
    return $the_datetime;
}
function jpg_get_dir_ts($in_dir) { #was GetDirEXIFtimestamp
    $the_highest = 0;
    $the_dir = get_option('jpg_picsdirectory').$in_dir;
    $directory = opendir($the_dir);
    while (false !== ($filename = readdir($directory))) {
	if ( $filename !== "." and $filename !== ".." ) {
	    $file_timestamp = jpg_get_file_ts($the_dir.'/'.$filename);
	    if ($file_timestamp >= $the_highest) { $the_highest = $file_timestamp; }
	}
    }    
    return $the_highest;
}
function jpg_add_new_if_new ($the_text, $the_timestamp) { #was addnewifnew
    if ( jpg_is_ts_new($the_timestamp) ) {
	return '<font color="#ffcc00"><b>NEW </b></font>'.$the_text;
    } else {
	return $the_text;
    }
}
function jpg_is_ts_new ($in_timestamp) { #was timestampnew
    $jpg_daysnew = get_option('jpg_daysnew');
    $cur_date = getdate();
    $past_date = mktime($cur_date['hours'], $cur_date['minutes'], $cur_date['seconds'], $cur_date['mon'], $cur_date['mday'] - $jpg_daysnew, $cur_date['year']);
    if ($in_timestamp >= $past_date ) {
	return true;
    } else {
	return false;
    }
}
function jpg_collection_files_array($the_dir) { #was MakeDirrArray
    $directory = opendir($the_dir);
    $onenew = false;
    $oneold = false;
    while (false !== ($filename = readdir($directory))) {
	$the_pic = $the_dir.'/'.$filename;
	if ( $filename !== "." and $filename !== ".." and jpg_valid_image($the_pic)) {
	    $this_timestamp = jpg_get_file_ts($the_pic);
	    $dir_files[$filename] = $this_timestamp;
	    if (jpg_is_ts_new( $this_timestamp)) { 
		$onenew = true; 
	    } else {
		$oneold = true;
	    }
	}
    }
    if ($onenew and $oneold) {
	if ( !$dir_files == NULL) {arsort($dir_files);}
    } else {
	if ( !$dir_files == NULL) {asort($dir_files);}
    }
    return $dir_files;
}

function jpg_collection_has_image($the_dir) { #new to JPG
	if (substr($the_dir, -2) == '/.' OR substr($the_dir,-3) == '/..') { return FALSE; }
	$error = error_reporting(E_ERROR);
	$directory = opendir($the_dir);
	$has_image = FALSE;
	while (false !== ($filename = readdir($directory))) {
		if ( $filename !== "." and $filename !== ".." and jpg_valid_image($the_dir.'/'.$filename)) {
			$has_image = TRUE;
		}
	}
	error_reporting($error);
	return $has_image;
}

function jpg_valid_image($the_file) { #new to JPG
    $pic_imagetype = exif_imagetype($the_file);
    if ($pic_imagetype == IMAGETYPE_GIF OR $pic_imagetype == IMAGETYPE_JPEG OR $pic_imagetype == IMAGETYPE_PNG) {
	return TRUE;
    } else {
	return FALSE;
    }
}

?>
