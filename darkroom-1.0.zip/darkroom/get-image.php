<?php # -*- php -*-
require_once($_SERVER['DOCUMENT_ROOT'] . '/' . 'wp-config.php');
$jpg_picsdirectory = jpg_get_option('jpg_picsdirectory');
$jpg_copyright = "� " . jpg_get_option('jpg_copyright');
$pic_file = $_SERVER['DOCUMENT_ROOT'] . '/' . $jpg_picsdirectory . $_REQUEST['file'];
$stripped_filename = substr(strstr($_REQUEST['file'], "/"),1);
$dot_in_filename = strrpos($stripped_filename, '.');
$thumb_height = 100;
$thumb_width = 150; #only used for creating an error thumbnail
$output_height = 600;
$output_width = 800;
$operation = $_REQUEST['op'];
$is_error = FALSE;

// Pre-2.6 compatibility
if ( ! defined( 'WP_CONTENT_URL' ) )
      define( 'WP_CONTENT_URL', get_option( 'siteurl' ) . '/wp-content' );
if ( ! defined( 'WP_CONTENT_DIR' ) )
      define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' );
if ( ! defined( 'WP_PLUGIN_URL' ) )
      define( 'WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins' );
if ( ! defined( 'WP_PLUGIN_DIR' ) )
      define( 'WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins' );

if (!file_exists($pic_file)) { 
    $is_error = TRUE;
} else {
    $pic_imagetype = exif_imagetype($pic_file);
    if (!$pic_imagetype) { $is_error = TRUE; }
}

switch ($pic_imagetype) {
 case IMAGETYPE_GIF:
    $source_image = @imagecreatefromgif($pic_file); 
    $func_output = 'imagegif'; break;
 case  IMAGETYPE_JPEG:
    $source_image = @imagecreatefromjpeg($pic_file); 
    $func_output = 'imagejpeg'; break;
 case  IMAGETYPE_PNG:
    $source_image = @imagecreatefrompng($pic_file); 
    $func_output = 'imagepng'; break;
 default:
    $is_error = TRUE;
}

if ($source_image == FALSE) {$is_error = TRUE; }

if ($operation === 'thumb') {
    $file_name = substr($stripped_filename, 0, $dot_in_filename) . '-thumb' . substr($stripped_filename, $dot_in_filename);
    $new_width = $thumb_width;
    $new_height = $thumb_height;
    if (!$is_error) {
	$source_width = imagesx($source_image);
	$source_height = imagesy($source_image);
	$target_height = $thumb_height;
	$target_width = ceil( $source_width * ($thumb_height / $source_height));
	$target_image = ImageCreateTrueColor($target_width, $target_height);
	ImageCopyResized( $target_image, $source_image, 0, 0, 0, 0, $target_width, $target_height, $source_width, $source_height);
    }
} elseif ($operation === 'image') {
    $file_name = substr($stripped_filename, 0, $dot_in_filename) . '-image' . substr($stripped_filename, $dot_in_filename);
    $new_width = $output_width;
    $new_height = $output_height;
    if (!$is_error) {
	$source_width = imagesx($source_image);
	$source_height = imagesy($source_image);
	if ( (($source_width > $output_width) AND ($source_width > $source_height)) OR (($source_height > $output_height) AND ($source_height > $source_width))) {
	    if ($source_width > $source_height) {
		$target_width = $output_width;
		$target_height = ceil($source_height * ($output_width/$source_width));
	    } else {
		$target_height = $output_height;
		$target_width = ceil ($source_width * ($output_height/$source_height));
	    }
	    $target_image = ImageCreateTrueColor($target_width, $target_height);
	    ImageCopyResized( $target_image, $source_image, 0, 0, 0, 0, $target_width, $target_height, $source_width, $source_height);
	} else {
	    $target_image = $source_image;
	}
	$green = imagecolorallocate($target_image, 153, 204, 102);
	$black = imagecolorallocate($target_image, 0, 0, 0);
	$font = WP_PLUGIN_DIR . '/darkroom/fonts/nevis.ttf';
	imagettftext($target_image, 12, 0, 12, $target_height - 8, $black, $font, $jpg_copyright);
	imagettftext($target_image, 12, 0, 10, $target_height - 10, $green, $font, $jpg_copyright);
    } 
} else {
    $do_not_output = TRUE;
}

if (!$is_error AND !$do_not_output) {
    header("Content-type: " . image_type_to_mime_type($pic_imagetype));
    header("Content-Disposition: inline; filename=\"$file_name\";");
    $image = $func_output($target_image);
}
if (($is_error OR $image == false) AND !$do_not_output) {
    if ($operation == 'output') { $operation = 'picture'; }
    if ($operation == 'thumb') { $operation = 'thumbnail'; }
    $the_header = "Content-type: image/jpeg";
    $the_image = imagecreatetruecolor($new_width,$new_height);
    $bgc = imagecolorallocate($the_image, 255, 255, 255);
    $tc = imagecolorallocate($the_image, 0, 0, 0);
    imagefilledrectangle($the_image, 1, 1, 148, 30, $bgc);
    imagestring($the_image, 1, 5, 5, "Error loading $operation.", $tc);
    header($the_header);
    $image = imagejpeg($the_image);
}

function jpg_get_option($setting) {
    global $wpdb;
    $sql = "SELECT option_value FROM $wpdb->options WHERE option_name = '$setting' LIMIT 1";
    $result = $wpdb->get_var($sql);
    return $result;
}
?>
